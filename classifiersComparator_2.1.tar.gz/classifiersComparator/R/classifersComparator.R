classifiersComparator <- function(trainSet,testSet) 
  UseMethod("classifiersComparator")



classifiersComparator.default <- function(trainSet,testSet) {
  evaluate.evaluate(testSet, trainSet)
  
}