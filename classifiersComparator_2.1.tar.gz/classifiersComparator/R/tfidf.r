# Piotr Jastrzebski
# Marcin Nazimek



tfidf.doIt <- function(){

}